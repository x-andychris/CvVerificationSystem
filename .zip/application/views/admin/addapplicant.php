<?php defined('BASEPATH') OR exit('No direct script access allowed');?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Loading the Header Section -->
    <?php $this->load->view('inc/layout/adminheader');?>
</head>

<body class="animsition">
    <div class="page-wrapper">
        <!-- MENU SIDEBAR-->
        <?php $this->load->view('inc/layout/adminsidebar');?>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class="page-container2">
            <!-- HEADER DESKTOP-->
            <header class="header-desktop2">
                <?php $this->load->view('inc/layout/admintopbar');?>
            </header>
            <!-- Start Hidden Side Bar -->
            <?php $this->load->view('inc/layout/adminhiddensidebar');?>
            <!-- End Hidden Side Bar -->
            <!-- END HEADER DESKTOP-->

            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="card">
                                    <div class="card-header">New Applicant</div>
                                    <div class="card-body">
                                        <form action="<?php echo base_url(); ?>admin/add_new_applicant" method="post"
                                            enctype="multipart/form-data">
                                            <div class="form-group">
                                                <label for="documentnumber" class="control-label mb-1"><b>Document
                                                        Number</b></label>
                                                <input id="documentnumber" name="documentnumber" type="text"
                                                    class="form-control" aria-required="true" aria-invalid="false"
                                                    placeholder="Enter the document number (E000001)" required />
                                            </div>
                                            <div class="form-group">
                                                <label for="name" class="control-label mb-1"><b>Fullname</b></label>
                                                <input id="fullname" name="fullname" type="text" class="form-control"
                                                    aria-required="true" aria-invalid="false"
                                                    placeholder="Enter the full name (JOHN DOE ADAMS)"
                                                    pattern="[a-zA-Z ]{2,60}" required />
                                            </div>
                                            <div class=" form-group">
                                                <label for="applicationtype" class="control-label mb-1"><b>Type of
                                                        Application</b></label>
                                                <select name="applicationtype" id="applicationtype" class="form-control"
                                                    required>
                                                    <option value="Evaluation">Evaluation</option>
                                                    <option value="2">Option #2</option>
                                                    <option value="3">Option #3</option>
                                                </select>
                                            </div>
                                            <div class="form-group has-success">
                                                <label for="verificationdate" class="control-label mb-1"><b>Verification
                                                        Date</b></label>
                                                <input id="verificationdate" name="verificationdate" type="tel"
                                                    class="form-control"
                                                    placeholder="Enter the verification date (June 1, 2021)" required />
                                            </div>
                                            <div class="form-group has-success">
                                                <label for="doc_title" class="control-label mb-1"><b>Document
                                                        Title</b></label>
                                                <select name="doc_title" id="doc_title" class="form-control" required>
                                                    <option value="West African Examinations Council (WAEC)">West
                                                        African Examinations Council (WAEC)</option>
                                                    <option value="National Examinations Council (NECO) ">National
                                                        Examinations Council (NECO) </option>
                                                    <option value="General Certificate of Education (GCE)">General
                                                        Certificate of Education (GCE)
                                                    </option>
                                                    <option value="National Business and Technical Examinations Board
                                                        (NABTEB)">National Business and Technical Examinations Board
                                                        (NABTEB)</option>
                                                </select>
                                            </div>
                                            <div class="form-group has-success">
                                                <label for="file" class="control-label mb-1"><b>Upload
                                                        Document</b></label>
                                                <input type="file" id="file" name="file" class="form-control-file"
                                                    required>
                                            </div>
                                            <div>
                                                <button id="add" type="submit" name="upload"
                                                    class="btn btn-lg btn-info btn-block">
                                                    <i class="fa fa-plus fa-lg"></i>&nbsp;
                                                    <span id="payment-button-amount">Add Applicant</span>
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="copyright">
                                    <p>
                                        Copyright © 2014 ESS.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- END PAGE CONTAINER-->
        </div>
    </div>

    <!-- Loading the scripts -->
    <?php $this->load->view('inc/layout/adminbottomscripts');?>
</body>

</html>
<!-- end document-->