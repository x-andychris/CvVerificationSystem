<?php defined('BASEPATH') OR exit('No direct script access allowed');?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Loading the Header Section -->
    <?php $this->load->view('inc/layout/adminheader');?>
</head>

<body class="animsition">
    <div class="page-wrapper">
        <!-- MENU SIDEBAR-->
        <?php $this->load->view('inc/layout/adminsidebar');?>
        <!-- END MENU SIDEBAR-->

        <!-- PAGE CONTAINER-->
        <div class="page-container2">
            <!-- HEADER DESKTOP-->
            <header class="header-desktop2">
                <?php $this->load->view('inc/layout/admintopbar');?>
            </header>
            <!-- Start Hidden Side Bar -->
            <?php $this->load->view('inc/layout/adminhiddensidebar');?>
            <!-- End Hidden Side Bar -->
            <!-- END HEADER DESKTOP-->

            <!-- Main Content starts here-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                <!-- DATA TABLE -->
                                <h3 class="title-5 m-b-35">View Applicants Data</h3>
                                <div class="table-data__tool">
                                    <div class="table-data__tool-left">
                                        <div class="rs-select2--light rs-select2--md">
                                            <select class="js-select2" name="property">
                                                <option selected="selected">All Applicants</option>
                                                <option value="">Active</option>
                                                <option value="">Disabled</option>
                                            </select>
                                            <div class="dropDownSelect2"></div>
                                        </div>
                                        <div class="rs-select2--light rs-select2--sm">
                                            <select class="js-select2" name="time">
                                                <option selected="selected">Today</option>
                                                <option value="">3 Days</option>
                                                <option value="">1 Week</option>
                                            </select>
                                            <div class="dropDownSelect2"></div>
                                        </div>

                                        <button class="au-btn-filter">
                                            <i class="zmdi zmdi-search"></i>
                                            <input id="searchInput" type="text" placeholder="Search..">
                                        </button>
                                    </div>
                                    <div class="table-data__tool-right">
                                        <button class="au-btn au-btn-icon au-btn--green au-btn--small"
                                            onclick="location.href='<?php echo base_url(); ?>admin/addapplicant'">
                                            <i class="zmdi zmdi-plus"></i>add applicant</button>
                                        <button class="au-btn au-btn-icon au-btn--green au-btn--small"
                                            onclick="window.print()" value="Print">
                                            <i class="zmdi zmdi-print"></i>Print</button>
                                    </div>
                                </div>
                                <div class="table-responsive table-responsive-data2">
                                    <table class="table table-data2">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Document Number</th>
                                                <th>Full Name</th>
                                                <th>Type</th>
                                                <th>Date</th>
                                                <th>Document Title</th>
                                                <th>Qr Code</th>
                                                <th>Views</th>
                                                <th></th>
                                                <th></th>
                                                <th></th>
                                            </tr>
                                        </thead>
                                        <tbody id="applicantsTable">
                                            <?php foreach($applicants -> result() as $row) :?>
                                            <tr class="tr-shadow">
                                                <td><?php echo $row -> ApplicantId;?></td>
                                                <td>
                                                    <span
                                                        class="block-email"><?php echo $row -> DocumentNumber;?></span>
                                                </td>
                                                <td class="desc"><?php echo $row -> DocumentOwner;?></td>
                                                <td><?php echo $row -> ApplicationType;?></td>
                                                <td>
                                                    <span
                                                        class="status--process"><?php echo $row -> VerificationDate;?></span>
                                                </td>
                                                <td><?php echo $row -> DocumentName;?></td>
                                                <!-- The Qr Code -->
                                                <td>
                                                    <img src="https://chart.googleapis.com/chart?chs=300x300&cht=qr&chl=<?php echo base_url(); ?>verify/<?php echo $row -> DocumentNumber;?>&choe=UTF-8"
                                                        title="Embeded Qr Code" />
                                                </td>
                                                <td><?php echo $row -> Views;?></td>
                                                <!-- For Preview -->
                                                <td>
                                                    <div class="table-data-feature">
                                                        <a href="<?php echo base_url(); ?>verify/<?php echo $row -> DocumentNumber;?>"
                                                            target="_blank">
                                                            <button class="item" data-toggle="tooltip"
                                                                data-placement="top" title="Preview Data">
                                                                <i class="zmdi zmdi-fullscreen-alt"></i>
                                                            </button>
                                                        </a>
                                                    </div>
                                                </td>
                                                <!-- For Edit -->
                                                <td>
                                                    <div class="table-data-feature">
                                                        <a
                                                            href="<?php echo base_url(); ?>admin/editapplicant/<?php echo $row -> ApplicantId;?>">
                                                            <button class="item" data-toggle="tooltip"
                                                                data-placement="top" title="Edit">
                                                                <i class="zmdi zmdi-edit"></i>
                                                            </button>
                                                        </a>
                                                    </div>
                                                </td>
                                                <!-- For Disable -->
                                                <td>
                                                    <div class="table-data-feature">
                                                        <button class="item" data-toggle="tooltip" data-placement="top"
                                                            title="Delete" style="color:red"
                                                            onclick="handledelete('<?php echo $row -> ApplicantId;?>')">
                                                            <i class="zmdi zmdi-delete" style="color:red"></i>
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr class="spacer"></tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                    <!-- Script for delete -->
                                    <script>
                                    var baseurl = <?php echo json_encode(base_url()); ?>;

                                    function handledelete(id) {
                                        if (confirm('Are you sure you want to delete Applicant ' + id + '?')) {
                                            // deleting the applicant
                                            window.location.href = '' + baseurl + 'admin/deleteapplicant/' + id;
                                        } else {
                                            // Do nothing!
                                        }
                                    }
                                    </script>
                                    <!-- Script for search -->
                                    <script>
                                    $(document).ready(function() {
                                        $("#searchInput").on("keyup", function() {
                                            var value = $(this).val().toLowerCase();
                                            $("#applicantsTable tr").filter(function() {
                                                $(this).toggle($(this).text().toLowerCase()
                                                    .indexOf(value) > -1)
                                            });
                                        });
                                    });
                                    </script>
                                </div>
                                <!-- END DATA TABLE -->
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="copyright">
                                    <p>Copyright © 2014 ESS</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- END PAGE CONTAINER-->
        </div>

    </div>

    <!-- Loading the scripts -->
    <?php $this->load->view('inc/layout/adminbottomscripts');?>

</body>

</html>
<!-- end document-->