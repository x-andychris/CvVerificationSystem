<?php

    class ess_model extends CI_model{
        function __construct(){
            parent:: __construct();
        }

        // creating an insert function
        public function addapplicant($applicant){
            // if statement to handle insert success
            if($this -> db -> insert("applicants",$applicant)){
                return true;
            }
        }

        // getting all applicants
        public function get_applicants(){
            $details=$this -> db-> query("select * from Applicants");
            return $details;
        }
        // update sum of applicant views
        public function update_applicants_view($documentid){
            $details=$this -> db-> query("update Applicants set Views = Views + 1 where DocumentNumber = '$documentid'");
            return $details;
        }

        // getting a specific applicant using document number
        public function get_applicant_details($id){
            $details=$this -> db-> query("select * from Applicants where DocumentNumber = '$id'");
            return $details;
        }

        // getting a specific applicant using applicant id
        public function get_applicant_details_id($id){
            $details=$this -> db-> query("select * from Applicants where ApplicantId = '$id'");
            return $details;
        }

        // validating a user
        public function validate_user($uname,$pwd){
            $details=$this -> db-> query("select * from Users where UserName = '$uname' && Password = '$pwd' ");
            return $details;
        }

        // creating an update statement
        public function updateapplicant($data,$applicantid){
            
            $this -> db -> set($data);

            // specifying the column/ condidtion where the update would be made
            $this -> db -> where("ApplicantId",$applicantid);

            // actual update
            if($this -> db -> update("Applicants",$data)){
                return true;
            }
        }

        // creating an delete statement
        public function deleteapplicant($applicantid){
            // if statement to handle delete success
            if($this -> db -> delete("Applicants","ApplicantId =".$applicantid)){
                return true;
            }
        }

        // update statement for the admin info
        public function updateprofile($data,$id){
            
            $this -> db -> set($data);

            // specifying the column/ condidtion where the update would be made
            $this -> db -> where("UserId",$id);

            // actual update
            if($this -> db -> update("Users",$data)){
                return true;
            }
        }
    }

?>