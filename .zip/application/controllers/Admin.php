<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this -> load -> helper('url');
		$this -> load -> helper('form');
        $this -> load -> model('ess_model');
		$this -> load -> database();
		$this->load->library('session');
	}
	// start of login section
    public function index()
	{
		// checking th esession to see if the user is logged in
		if($this->session->userdata('userId') != '') {redirect('admin/dashboard');return;}
		$this->load->view('admin/index.php');
	}

	public function validate_user()
	{
        $username = $_POST['username'];
		$password = $_POST['password'];
        $data = [];
        $user = $this -> ess_model -> validate_user($username,$password);
        if ($user->num_rows() == 0)
        {
            session_start();
            $_SESSION['errors']= "Incorrect Details Provided";
            redirect('admin/');
            return;
        }

        $row =  $user->row();
		$this->session->set_userdata('userId', ''.$row -> UserId);
		$this->session->set_userdata('userUName', ''.$row -> UserName);
		$this->session->set_userdata('userPassword', ''.$row -> Password);
		redirect('admin/dashboard');
	}

	// end of login section

	// start of logout section
    public function logout()
	{
		$this->session->set_userdata('userId', '');
		redirect('admin/dashboard');
	}
	// end of logout section
	// start of admin dashboard
	public function dashboard()
	{
		// checking th esession to see if the user is logged in
		if($this->session->userdata('userId') == '') {redirect('admin/');return;}
        $data = [];
		$users = $this -> ess_model -> get_applicants();

		$data['noofusers'] =  $users->num_rows();
		$data['page'] =  "dashboard";
		
		$sumofviews = 0;
		foreach ($users->result() as $row){
			$sumofviews = $sumofviews + $row -> Views;
		}
		$data['sumofviews'] = $sumofviews;
		
		$this->load->view('admin/dashboard.php',$data);
	}
	// end of admin dashboard

	// start of add applicant

	public function addapplicant()
	{
		// checking th esession to see if the user is logged in
		if($this->session->userdata('userId') == '') {redirect('admin/');return;}
        $data = [];
		$data['page'] =  "addapplicant";
		
		$this->load->view('admin/addapplicant.php',$data);
	}

	public function add_new_applicant(){
		// checking th esession to see if the user is logged in
		if($this->session->userdata('userId') == '') {redirect('admin/');return;}
		// Check form submit or not 
		// if($this->input->post('upload') != NULL ){
		$documentnumber = $_POST['documentnumber'];
		$fullname = $_POST['fullname'];
		$applicationtype= $_POST['applicationtype'];
		$verificationdate= $_POST['verificationdate'];
		$doctitle= $_POST['doc_title'];

		// generating a new file name
		$newfilename = "";
		$exploded = explode(".",$_FILES["file"]["name"]);
		try{$newfilename = time() . '_' . rand(100, 999) . '.' . end($exploded);}
		catch(Exception $e){}
		
		// compiling the information into an array
		$data = array(
			'DocumentNumber' => $documentnumber,
			'DocumentOwner' => strtoupper($fullname),
			'ApplicationType' => strtoupper($applicationtype),
			'VerificationDate' => $verificationdate,
			'DocumentName' => $doctitle,
			'Document' => $newfilename,
			'Views' => 0
		);
		
		// configuring the file
		$config['allowed_types'] = 'jpg|png|pdf|docx';
		$config['upload_path'] = './assets/documents/';
		$config['file_name'] = $newfilename;
		$this -> load -> library('upload',$config);
		// performing upload and checking if it was successful
		if($this -> upload -> do_upload('file')){
			// inserting into the database if file upload was successful
			$status = $this -> ess_model -> addapplicant($data);
			// action if insert was successful
			if($status){redirect('admin/viewapplicants');}
			// if not successful
			else{redirect('admin/addapplicant');}
		}else{
			redirect('admin/addapplicant');
		}
	}
	// end of add applicant document

	// start of view all applicants
	public function viewapplicants()
	{
		// checking th esession to see if the user is logged in
		if($this->session->userdata('userId') == '') {redirect('admin/');return;}
        $data = [];
		$data['page'] =  "viewapplicants";
		$data['applicants'] = $this -> ess_model -> get_applicants();
		
		$this->load->view('admin/viewapplicants.php',$data);
	}

	// end of view all applicants
	// start of edit applicant
	public function editapplicant($id){
		// checking th esession to see if the user is logged in
		if($this->session->userdata('userId') == '') {redirect('admin/');return;}
		$this -> load -> helper('form');
        $data = [];
		$data['page'] =  "editapplicant";
        $product = $this -> ess_model -> get_applicant_details_id($id);
        if ($product->num_rows() == 0)
        {
            $this->load->view('error_404');
            return;
        }

        $data['applicantinfo'] =  $product->row();
		$this->load->view('admin/editapplicant.php',$data);
	}

	public function editapplicant_details(){
		// checking th esession to see if the user is logged in
		if($this->session->userdata('userId') == '') {redirect('admin/');return;}
		// Check form submit or not 
		// if($this->input->post('upload') != NULL ){
		$applicantid = $_POST['applicantid'];
		$documentnumber = $_POST['documentnumber'];
		$fullname = $_POST['fullname'];
		$applicationtype= $_POST['applicationtype'];
		$verificationdate= $_POST['verificationdate'];
		$doctitle= $_POST['doc_title'];
		$filedefault= $_POST['filedefault'];

		// generating a new file name
		$newfilename = "";
		$exploded = explode(".",$_FILES["file"]["name"]);
		try{$newfilename = time() . '_' . rand(100, 999) . '.' . end($exploded);}
		catch(Exception $e){}

		// checking if any file was uploaded at all
		// changing the new file name to the previous if none was uploaded
		if ($_FILES["file"]["name"] == ""){$newfilename = $filedefault;}

		// compiling the information into an array
		$data = array(
			'DocumentNumber' => $documentnumber,
			'DocumentOwner' => strtoupper($fullname),
			'ApplicationType' => strtoupper($applicationtype),
			'VerificationDate' => $verificationdate,
			'DocumentName' => $doctitle,
			'Document' => $newfilename,
			'Views' => 0
		);
		
		
		// configuring the file
		$config['allowed_types'] = 'jpg|png|pdf|docx';
		$config['upload_path'] = './assets/documents/';
		$config['file_name'] = $newfilename;
		$this -> load -> library('upload',$config);
		// performing upload and checking if it was successful
		if($this -> upload -> do_upload('file')){
			// inserting into the database if file upload was successful
			$status = $this -> ess_model -> updateapplicant($data,$applicantid);
			// action if insert was successful
			if($status){redirect('admin/viewapplicants');}
			// if not successful
			else{redirect('admin/editapplicant');}
		}else{
			// inserting into the database with previous file if file upload was not successful
			$status = $this -> ess_model -> updateapplicant($data,$applicantid);
			// action if insert was successful
			if($status){redirect('admin/viewapplicants');}
			// if not successful
			else{redirect('admin/editapplicant');}
		}
	}
    // end of edit applicants
	// start of delete applicant
	public function deleteapplicant($id){
		// checking th esession to see if the user is logged in
		if($this->session->userdata('userId') == '') {redirect('admin/');return;}
		$this -> load -> helper('form');
        $data = [];
        $status = $this -> ess_model -> deleteapplicant($id);
        if ($status)
        {
            //$this->load->view('error_404');
			redirect('admin/viewapplicants');
            return;
        }

		redirect('admin/viewapplicants');
	}
	// end of delete applicant

	public function updateprofile(){
		// checking th esession to see if the user is logged in
		if($this->session->userdata('userId') == '') {redirect('admin/');return;}
		$data = [];
		$data['page'] = "updateprofile";

		$data['username'] =  $this->session->userdata('userUName');
		$data['password'] =  $this->session->userdata('userPassword');

		$this->load->view('admin/updateprofile.php',$data);
	}
	public function updateprofileinfo(){
		// checking th esession to see if the user is logged in
		if($this->session->userdata('userId') == '') {redirect('admin/');return;}

		$id = $this->session->userdata('userId');
		$username = $_POST['username'];
		$password = $_POST['password'];

		// compiling the information into an array
		$data = array(
			'UserName' => $username,
			'Password' => $password
		);

		$status = $this -> ess_model -> updateprofile($data,$id);
		// action if update was successful
		if($status){redirect('admin/viewapplicants');}
		// if not successful
		else{redirect('admin/addapplicant');}
	}
}